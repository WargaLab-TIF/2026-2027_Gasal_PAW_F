<?php
include "koneksi.php";

// $mulai   = $_GET['tanggal_mulai'];
// $selesai = $_GET['tanggal_selesai'];
if (isset($_GET['tanggal_mulai']) && isset($_GET['tanggal_selesai'])) {
    $mulai   = $_GET['tanggal_mulai'];
    $selesai = $_GET['tanggal_selesai'];
} else {
    $mulai   = date("Y-m-01");
    $selesai = date("Y-m-d");
}

header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=rekap_penjualan.xls");

$sql = "SELECT waktu_transaksi, SUM(total) AS total_harian
        FROM transaksi
        WHERE waktu_transaksi BETWEEN '$mulai' AND '$selesai'
        GROUP BY waktu_transaksi
        ORDER BY waktu_transaksi";
$hasil = mysqli_query($conn, $sql);
?>
<table border="1">
    <tr>
        <th>No</th>
        <th>Total Pendapatan</th>
        <th>Tanggal Transaksi</th>
    </tr>
    <?php
    $no = 1;
    while ($row = mysqli_fetch_assoc($hasil)) {
        echo "<tr>";
        echo "<td>" . $no . "</td>";
        echo "<td>" . $row['total_harian'] . "</td>";
        echo "<td>" . $row['waktu_transaksi'] . "</td>";
        echo "</tr>";
        $no++;
    }
    ?>
</table>
