<?php
include "koneksi.php";

if (isset($_GET['tanggal_mulai'])) {
    $mulai   = $_GET['tanggal_mulai'];
    $selesai = $_GET['tanggal_selesai'];
} else {
    $mulai   = date("Y-m-01");
    $selesai = date("Y-m-d");
}

$sql = "SELECT waktu_transaksi, SUM(total) AS total_harian
        FROM transaksi
        WHERE waktu_transaksi BETWEEN '$mulai' AND '$selesai'
        GROUP BY waktu_transaksi
        ORDER BY waktu_transaksi";
$hasil = mysqli_query($conn, $sql);

$sql2 = "SELECT COUNT(DISTINCT pelanggan_id) AS jml_pelanggan,
                SUM(total) AS total_semua
         FROM transaksi
         WHERE waktu_transaksi BETWEEN '$mulai' AND '$selesai'";
$ringkasan = mysqli_fetch_assoc(mysqli_query($conn, $sql2));

$tanggal = array();
$total   = array();
$data_tabel = array();
while ($row = mysqli_fetch_assoc($hasil)) {
    $tanggal[] = $row['waktu_transaksi'];
    $total[]   = $row['total_harian'];
    $data_tabel[] = $row;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Laporan Penjualan</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid black; padding: 6px; }
        .card { border: 1px solid black; padding: 10px; margin-top: 10px; }

        @media print {
            .no-print { display: none; }
        }
    </style>
</head>
<body>

<h2>Laporan Penjualan</h2>

<!-- Form filter -->
<form method="GET" class="no-print">
    Tanggal Mulai:
    <input type="date" name="tanggal_mulai" value="<?php echo $mulai; ?>">
    Tanggal Selesai:
    <input type="date" name="tanggal_selesai" value="<?php echo $selesai; ?>">
    <button type="submit">Tampilkan</button>
</form>

<br>
<button onclick="window.print()" class="no-print">Cetak</button>
<a href="excel.php?tanggal_mulai=<?php echo $mulai; ?>&tanggal_selesai=<?php echo $selesai; ?>" class="no-print">
    <button>Excel</button>
</a>

<canvas id="grafik" height="100"></canvas>

<table>
    <tr>
        <th>No</th>
        <th>Total Pendapatan</th>
        <th>Tanggal Transaksi</th>
    </tr>
    <?php
    $no = 1;
    foreach ($data_tabel as $row) {
        echo "<tr>";
        echo "<td>" . $no . "</td>";
        echo "<td>Rp " . number_format($row['total_harian']) . "</td>";
        echo "<td>" . $row['waktu_transaksi'] . "</td>";
        echo "</tr>";
        $no++;
    }
    ?>
</table>

<div class="card">
    Jumlah Pelanggan Unik: <b><?php echo $ringkasan['jml_pelanggan']; ?></b><br>
    Total Pendapatan Keseluruhan: <b>Rp <?php echo number_format($ringkasan['total_semua']); ?></b>
</div>

<script>
var tanggal = <?php echo json_encode($tanggal); ?>;
var total   = <?php echo json_encode($total); ?>;

new Chart(document.getElementById("grafik"), {
    type: "bar",
    data: {
        labels: tanggal,
        datasets: [{
            label: "Total Pendapatan",
            data: total,
            backgroundColor: "blue"
        }]
    },
    options: {
        animation: false
    }
});
</script>

</body>
</html>
