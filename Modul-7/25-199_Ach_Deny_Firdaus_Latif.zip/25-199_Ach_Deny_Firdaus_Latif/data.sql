-- Data contoh (opsional) untuk menguji halaman laporan
USE penjualan;

INSERT INTO supplier (nama, telp, alamat) VALUES
('PT Sumber Makmur', '031555111', 'Surabaya'),
('CV Jaya Abadi', '031555222', 'Sidoarjo');

INSERT INTO barang (kode_barang, nama_barang, harga, stok, supplier_id) VALUES
('BRG001', 'Buku Tulis', 5000, 100, 1),
('BRG002', 'Pulpen', 3000, 200, 1),
('BRG003', 'Penghapus', 2000, 150, 2);

INSERT INTO pelanggan (id, nama, jenis_kelamin, telp, alamat) VALUES
('P001', 'Andi', 'L', '081111111', 'Surabaya'),
('P002', 'Siti', 'P', '082222222', 'Gresik'),
('P003', 'Budi', 'L', '083333333', 'Malang');

INSERT INTO transaksi (waktu_transaksi, keterangan, total, pelanggan_id) VALUES
('2026-11-10', 'Pembelian alat tulis', 25000, 'P001'),
('2026-11-10', 'Pembelian pulpen', 15000, 'P002'),
('2026-11-11', 'Pembelian buku', 50000, 'P001'),
('2026-11-12', 'Pembelian campur', 35000, 'P003'),
('2026-11-13', 'Pembelian penghapus', 10000, 'P002'),
('2026-11-14', 'Pembelian buku', 40000, 'P003');

INSERT INTO transaksi_detail (transaksi_id, barang_id, harga, qty) VALUES
(1, 1, 5000, 5),
(2, 2, 3000, 5),
(3, 1, 5000, 10),
(4, 2, 3000, 5),
(5, 3, 2000, 5),
(6, 1, 5000, 8);

INSERT INTO pembayaran (waktu_bayar, total, metode, transaksi_id) VALUES
('2026-11-10 09:00:00', 25000, 'TUNAI', 1),
('2026-11-10 10:30:00', 15000, 'TRANSFER', 2),
('2026-11-11 11:00:00', 50000, 'EDC', 3),
('2026-11-12 13:15:00', 35000, 'TUNAI', 4),
('2026-11-13 14:00:00', 10000, 'TUNAI', 5),
('2026-11-14 08:45:00', 40000, 'TRANSFER', 6);

INSERT INTO user (username, password, nama, alamat, hp, level) VALUES
('admin', MD5('admin123'), 'Administrator', 'Surabaya', '08123456789', 1);