CREATE DATABASE IF NOT EXISTS penjualan;
USE penjualan;

CREATE TABLE supplier (
    id     INT NOT NULL AUTO_INCREMENT,
    nama   VARCHAR(100) NOT NULL,
    telp   VARCHAR(12),
    alamat TEXT,
    PRIMARY KEY (id)
) ENGINE=InnoDB;

CREATE TABLE barang (
    id          INT NOT NULL AUTO_INCREMENT,
    kode_barang VARCHAR(10) NOT NULL,
    nama_barang VARCHAR(100) NOT NULL,
    harga       INT NOT NULL,
    stok        INT NOT NULL,
    supplier_id INT NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY kode_barang (kode_barang),
    FOREIGN KEY (supplier_id) REFERENCES supplier(id)
) ENGINE=InnoDB;

CREATE TABLE pelanggan (
    id            VARCHAR(20) NOT NULL,
    nama          VARCHAR(100) NOT NULL,
    jenis_kelamin ENUM('L','P') NOT NULL,
    telp          VARCHAR(12),
    alamat        TEXT,
    PRIMARY KEY (id)
) ENGINE=InnoDB;

CREATE TABLE transaksi (
    id              INT NOT NULL AUTO_INCREMENT,
    waktu_transaksi DATE NOT NULL,
    keterangan      TEXT,
    total           INT NOT NULL,
    pelanggan_id    VARCHAR(20) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (pelanggan_id) REFERENCES pelanggan(id)
) ENGINE=InnoDB;

CREATE TABLE transaksi_detail (
    transaksi_id INT NOT NULL,
    barang_id    INT NOT NULL,
    harga        INT NOT NULL,
    qty          INT NOT NULL,
    PRIMARY KEY (transaksi_id, barang_id),
    FOREIGN KEY (transaksi_id) REFERENCES transaksi(id),
    FOREIGN KEY (barang_id)    REFERENCES barang(id)
) ENGINE=InnoDB;

CREATE TABLE pembayaran (
    id           INT NOT NULL AUTO_INCREMENT,
    waktu_bayar  DATETIME NOT NULL,
    total        INT NOT NULL,
    metode       ENUM('TUNAI','TRANSFER','EDC') NOT NULL,
    transaksi_id INT NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (transaksi_id) REFERENCES transaksi(id)
) ENGINE=InnoDB;

CREATE TABLE user (
    id_user  TINYINT NOT NULL AUTO_INCREMENT,
    username VARCHAR(30) NOT NULL,
    password VARCHAR(35) NOT NULL,
    nama     VARCHAR(50) NOT NULL,
    alamat   VARCHAR(150),
    hp       VARCHAR(20),
    level    TINYINT(1) NOT NULL,
    PRIMARY KEY (id_user),
    UNIQUE KEY username (username)
) ENGINE=InnoDB;